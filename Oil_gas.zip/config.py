
EIA_key='YWpEpPTFDAeie1sB4qd65xfeXhGL8JReg2rW60xM'

quandle_API='_xabvwM4SomwpjiJ7cbW'

EIA_API='YWpEpPTFDAeie1sB4qd65xfeXhGL8JReg2rW60xM'

tingo_API='8c5fbd90efc36c18a9a751b41bf6cc71b840917d'


